import { useEffect, useState, useCallback } from 'react'
import { DeskThing } from '@deskthing/client'

const deskthing = DeskThing

// ============================================
// TYPE DEFINITIONS
// ============================================
interface SolarData {
  updated: string
  solarflux: string
  aindex: string
  kindex: string
  kindexnt: string
  xray: string
  sunspots: string
  heliumline: string
  protonflux: string
  electronflux: string
  aurora: string
  normalization: string
  latdegree: string
  solarwind: string
  magneticfield: string
  geomagfield: string
  signalnoise: string
  fof2: string
  muffactor: string
  muf: string
  band80m_day: string
  band80m_night: string
  band40m_day: string
  band40m_night: string
  band30m_day: string
  band30m_night: string
  band20m_day: string
  band20m_night: string
  band17m_day: string
  band17m_night: string
  band15m_day: string
  band15m_night: string
  band12m_day: string
  band12m_night: string
  band10m_day: string
  band10m_night: string
}

interface POTASpot {
  spotId: number
  activator: string
  frequency: string
  mode: string
  reference: string
  parkName: string
  locationDesc: string
  spotTime: string
  spotter: string
  comments: string
  source: string
  name: string
}

interface SOTASpot {
  id: number
  timeStamp: string
  comments: string
  callsign: string
  associationCode: string
  summitCode: string
  activatorCallsign: string
  activatorName: string
  frequency: string
  mode: string
  summitDetails: string
}

interface TimeData {
  utc: string
  utcDate: string
  utcDay: string
  local: string
  localDate: string
  localTimezone: string
  sunriseUTC: string
  sunsetUTC: string
  isDaytime: boolean
  grayLineInfo: string
}

interface HamClockData {
  solar: SolarData | null
  pota: POTASpot[]
  sota: SOTASpot[]
  time: TimeData
  lastUpdate: string
}

// ============================================
// HELPER FUNCTIONS
// ============================================
const getConditionText = (condition: string): string => {
  const c = condition?.toLowerCase() || ''
  if (c.includes('good') || c.includes('excellent')) return 'Good'
  if (c.includes('fair') || c.includes('normal')) return 'Fair'
  if (c.includes('poor') || c.includes('bad')) return 'Poor'
  return '—'
}

const getConditionColor = (condition: string): string => {
  const c = condition?.toLowerCase() || ''
  if (c.includes('good') || c.includes('excellent')) return 'text-emerald-400'
  if (c.includes('fair') || c.includes('normal')) return 'text-amber-300'
  if (c.includes('poor') || c.includes('bad')) return 'text-rose-400'
  return 'text-white/50'
}

const getKStatus = (k: string): string => {
  const kNum = parseInt(k) || 0
  if (kNum <= 1) return 'Quiet'
  if (kNum <= 2) return 'Unsettled'
  if (kNum <= 3) return 'Active'
  if (kNum <= 4) return 'Minor Storm'
  return 'Major Storm'
}

const cleanValue = (value?: string): string => {
  if (!value) return '--'
  const v = value.toLowerCase()
  if (v === 'norpt' || v === 'n/a' || v === 'none' || v === '') return '--'
  return value
}

const formatTimeAgo = (isoString: string): string => {
  if (!isoString) return ''
  const now = new Date()
  const then = new Date(isoString)
  const diffMs = now.getTime() - then.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  
  if (diffMins < 1) return 'now'
  if (diffMins < 60) return `${diffMins}m`
  const diffHours = Math.floor(diffMins / 60)
  if (diffHours < 24) return `${diffHours}h`
  return `${Math.floor(diffHours / 24)}d`
}

// ============================================
// BACKGROUND WRAPPER
// ============================================
const PageWrapper = ({ children }: { children: React.ReactNode }) => (
  <div className="h-full w-full bg-gradient-to-br from-blue-950 via-sky-900 to-slate-900 text-white flex flex-col overflow-hidden">
    {children}
  </div>
)

// ============================================
// PANEL 1: OVERVIEW (Weather Style)
// ============================================
const OverviewPanel = ({ data }: { data: HamClockData }) => {
  const solar = data.solar
  const kIndex = solar?.kindex || '--'
  
  return (
    <PageWrapper>
      {/* Hero: K-Index */}
      <div className="flex-1 flex flex-col items-center pt-16">
        <div className="text-9xl font-extralight tracking-tight">
          K{kIndex}
        </div>
        <div className="text-3xl font-light text-white/70 mt-2">
          {getKStatus(kIndex)}
        </div>
        <div className="text-xl text-white/50 mt-2">
          SFI {solar?.solarflux || '--'} • SSN {solar?.sunspots || '--'} • A {solar?.aindex || '--'}
        </div>
      </div>

      {/* Time bar */}
      <div className="flex justify-between items-center py-5 px-8 border-t border-white/10">
        <div className="text-center">
          <div className="text-4xl font-light">{data.time.utc}</div>
          <div className="text-base text-white/50 uppercase tracking-widest mt-1">UTC</div>
        </div>
        <div className="h-16 w-px bg-white/20" />
        <div className="text-center">
          <div className="text-4xl font-light">{data.time.local}</div>
          <div className="text-base text-white/50 uppercase tracking-widest mt-1">Local</div>
        </div>
      </div>

      {/* Band conditions cards */}
      <div className="flex gap-3 px-6 pb-6">
        {['80m', '40m', '20m', '15m', '10m'].map((band) => {
          const dayKey = `band${band.replace('m', '')}m_day` as keyof SolarData
          const condition = solar?.[dayKey] || ''
          return (
            <div key={band} className="flex-1 bg-white/10 backdrop-blur-sm rounded-2xl p-4 text-center">
              <div className="text-xl font-medium">{band}</div>
              <div className={`text-lg mt-1 ${getConditionColor(condition)}`}>
                {getConditionText(condition)}
              </div>
            </div>
          )
        })}
      </div>

      {/* Panel indicator */}
      <div className="text-center pb-4 text-white/40 text-base">◀ 1/5 ▶</div>
    </PageWrapper>
  )
}

// ============================================
// PANEL 2: SOLAR DETAILS
// ============================================
const SolarPanel = ({ data }: { data: HamClockData }) => {
  const solar = data.solar

  return (
    <PageWrapper>
      {/* Header */}
      <div className="px-6 pt-6 pb-4">
        <div className="text-4xl font-extralight">☀️ Solar</div>
        <div className="text-lg text-white/50 mt-1">Space Weather Conditions</div>
      </div>

      {/* Stats grid */}
      <div className="flex-1 grid grid-cols-2 gap-4 px-6">
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5">
          <div className="text-white/50 text-base uppercase tracking-wider mb-4">Solar</div>
          <div className="space-y-4">
            <StatRow label="Solar Flux" value={solar?.solarflux} />
            <StatRow label="Sunspots" value={solar?.sunspots} />
            <StatRow label="X-Ray" value={solar?.xray} />
            <StatRow label="Proton Flux" value={solar?.protonflux} />
          </div>
        </div>
        
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-5">
          <div className="text-white/50 text-base uppercase tracking-wider mb-4">Geomagnetic</div>
          <div className="space-y-4">
            <StatRow label="K-Index" value={solar?.kindex} />
            <StatRow label="A-Index" value={solar?.aindex} />
            <StatRow label="Solar Wind" value={solar?.solarwind} suffix=" km/s" />
            <StatRow label="Bz Field" value={solar?.magneticfield} suffix=" nT" />
          </div>
        </div>
      </div>

      {/* Updated time */}
      <div className="text-center py-4 text-white/40 text-base">
        Updated: {solar?.updated || 'Never'}
      </div>
      <div className="text-center pb-4 text-white/40 text-base">◀ 2/5 ▶</div>
    </PageWrapper>
  )
}

const StatRow = ({ label, value, suffix = '' }: { label: string; value?: string; suffix?: string }) => (
  <div className="flex justify-between items-center">
    <span className="text-white/60 text-lg">{label}</span>
    <span className="text-2xl font-light">{value || '--'}{value ? suffix : ''}</span>
  </div>
)

// ============================================
// PANEL 3: PROPAGATION (Weather-style grid)
// ============================================
const PropagationPanel = ({ data }: { data: HamClockData }) => {
  const solar = data.solar
  
  const bands = [
    { name: '160m', dayKey: 'band80m_day', nightKey: 'band80m_night' }, // Use 80m data as proxy
    { name: '80m', dayKey: 'band80m_day', nightKey: 'band80m_night' },
    { name: '60m', dayKey: 'band80m_day', nightKey: 'band80m_night' }, // Use 80m data as proxy
    { name: '40m', dayKey: 'band40m_day', nightKey: 'band40m_night' },
    { name: '30m', dayKey: 'band30m_day', nightKey: 'band30m_night' },
    { name: '20m', dayKey: 'band20m_day', nightKey: 'band20m_night' },
    { name: '17m', dayKey: 'band17m_day', nightKey: 'band17m_night' },
    { name: '15m', dayKey: 'band15m_day', nightKey: 'band15m_night' },
    { name: '12m', dayKey: 'band12m_day', nightKey: 'band12m_night' },
    { name: '10m', dayKey: 'band10m_day', nightKey: 'band10m_night' },
  ]

  // Determine if it's currently day or night (simplified)
  const isDaytime = data.time.isDaytime

  const getConditionBg = (condition: string): string => {
    const c = condition?.toLowerCase() || ''
    if (c.includes('good') || c.includes('excellent')) return 'bg-emerald-500/30 border-emerald-400/50'
    if (c.includes('fair') || c.includes('normal')) return 'bg-amber-500/30 border-amber-400/50'
    if (c.includes('poor') || c.includes('bad')) return 'bg-rose-500/30 border-rose-400/50'
    return 'bg-white/10 border-white/20'
  }

  return (
    <PageWrapper>
      {/* Header */}
      <div className="px-6 pt-5 pb-3 flex justify-between items-center">
        <div>
          <div className="text-3xl font-extralight">📊 Propagation</div>
          <div className="text-base text-white/50 mt-1">HF Band Conditions • {isDaytime ? '☀️ Day' : '🌙 Night'}</div>
        </div>
      </div>

      {/* Weather-style band grid - 2 rows of 5 */}
      <div className="flex-1 px-4 pb-2">
        <div className="grid grid-cols-5 gap-2 mb-2">
          {bands.slice(0, 5).map((band) => {
            const condition = isDaytime 
              ? solar?.[band.dayKey as keyof SolarData] || ''
              : solar?.[band.nightKey as keyof SolarData] || ''
            return (
              <div 
                key={band.name} 
                className={`rounded-xl border p-3 text-center ${getConditionBg(condition)}`}
              >
                <div className="text-white text-xl font-semibold">{band.name}</div>
                <div className={`text-base font-medium mt-1 ${getConditionColor(condition)}`}>
                  {getConditionText(condition)}
                </div>
              </div>
            )
          })}
        </div>
        <div className="grid grid-cols-5 gap-2">
          {bands.slice(5, 10).map((band) => {
            const condition = isDaytime 
              ? solar?.[band.dayKey as keyof SolarData] || ''
              : solar?.[band.nightKey as keyof SolarData] || ''
            return (
              <div 
                key={band.name} 
                className={`rounded-xl border p-3 text-center ${getConditionBg(condition)}`}
              >
                <div className="text-white text-xl font-semibold">{band.name}</div>
                <div className={`text-base font-medium mt-1 ${getConditionColor(condition)}`}>
                  {getConditionText(condition)}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Legend */}
      <div className="mx-6 mb-2 flex justify-center gap-6 text-sm">
        <span className="flex items-center gap-2"><span className="w-3 h-3 rounded bg-emerald-500/50"></span> Good</span>
        <span className="flex items-center gap-2"><span className="w-3 h-3 rounded bg-amber-500/50"></span> Fair</span>
        <span className="flex items-center gap-2"><span className="w-3 h-3 rounded bg-rose-500/50"></span> Poor</span>
      </div>

      {/* Solar stats bar */}
      <div className="mx-6 mb-4 bg-white/10 rounded-xl px-4 py-3 flex justify-around text-base">
        <span className="text-white/70">SFI <span className="text-white font-semibold">{solar?.solarflux || '--'}</span></span>
        <span className="text-white/70">SSN <span className="text-white font-semibold">{solar?.sunspots || '--'}</span></span>
        <span className="text-white/70">K <span className="text-white font-semibold">{solar?.kindex || '--'}</span></span>
        <span className="text-white/70">A <span className="text-white font-semibold">{solar?.aindex || '--'}</span></span>
      </div>

      <div className="text-center pb-4 text-white/40 text-base">◀ 3/5 ▶</div>
    </PageWrapper>
  )
}

// ============================================
// PANEL 4: POTA SPOTS (Compact for more spots)
// ============================================
const POTAPanel = ({ data, scrollOffset }: { data: HamClockData; scrollOffset: number }) => {
  const visibleSpots = data.pota.slice(scrollOffset, scrollOffset + 6)

  return (
    <PageWrapper>
      {/* Header - more compact */}
      <div className="px-5 pt-4 pb-2 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <span className="text-3xl">🏕️</span>
          <div>
            <div className="text-2xl font-light">POTA Spots</div>
          </div>
        </div>
        <div className="text-xl font-light text-emerald-400">{data.pota.length} active</div>
      </div>

      {/* Spots list - compact rows */}
      <div className="flex-1 mx-4 bg-white/10 backdrop-blur-sm rounded-2xl overflow-hidden">
        {visibleSpots.length > 0 ? (
          <div className="divide-y divide-white/5">
            {visibleSpots.map((spot, i) => (
              <div key={spot.spotId || i} className="px-4 py-2.5">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <span className="text-xl font-semibold text-white">{spot.activator}</span>
                    <span className="text-sm text-white/40">{spot.mode}</span>
                  </div>
                  <span className="text-lg font-light text-sky-300">{spot.frequency}</span>
                </div>
                <div className="flex justify-between items-center mt-0.5">
                  <span className="text-base text-emerald-400 font-medium">{spot.reference}</span>
                  <span className="text-sm text-white/40">{formatTimeAgo(spot.spotTime)}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-white/40 text-xl">
            No POTA spots available
          </div>
        )}
      </div>

      {/* Scroll indicator */}
      <div className="text-center py-2 text-white/40 text-sm">
        {data.pota.length > 6 ? (
          <span>↕ Scroll for more • {scrollOffset + 1}-{Math.min(scrollOffset + 6, data.pota.length)} of {data.pota.length}</span>
        ) : (
          <span>{data.pota.length} spots</span>
        )}
      </div>
      <div className="text-center pb-3 text-white/40 text-base">◀ 4/5 ▶</div>
    </PageWrapper>
  )
}

// ============================================
// PANEL 5: SOTA SPOTS (Compact for more spots)
// ============================================
const SOTAPanel = ({ data, scrollOffset }: { data: HamClockData; scrollOffset: number }) => {
  const visibleSpots = data.sota.slice(scrollOffset, scrollOffset + 6)

  return (
    <PageWrapper>
      {/* Header - more compact */}
      <div className="px-5 pt-4 pb-2 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <span className="text-3xl">⛰️</span>
          <div>
            <div className="text-2xl font-light">SOTA Spots</div>
          </div>
        </div>
        <div className="text-xl font-light text-orange-400">{data.sota.length} active</div>
      </div>

      {/* Spots list - compact rows */}
      <div className="flex-1 mx-4 bg-white/10 backdrop-blur-sm rounded-2xl overflow-hidden">
        {visibleSpots.length > 0 ? (
          <div className="divide-y divide-white/5">
            {visibleSpots.map((spot, i) => (
              <div key={spot.id || i} className="px-4 py-2.5">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <span className="text-xl font-semibold text-white">{spot.activatorCallsign}</span>
                    <span className="text-sm text-white/40">{spot.mode}</span>
                  </div>
                  <span className="text-lg font-light text-sky-300">{spot.frequency}</span>
                </div>
                <div className="flex justify-between items-center mt-0.5">
                  <span className="text-base text-orange-400 font-medium">{spot.associationCode}/{spot.summitCode}</span>
                  <span className="text-sm text-white/40">{formatTimeAgo(spot.timeStamp)}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-white/40 text-xl">
            No SOTA spots available
          </div>
        )}
      </div>

      {/* Scroll indicator */}
      <div className="text-center py-2 text-white/40 text-sm">
        {data.sota.length > 6 ? (
          <span>↕ Scroll for more • {scrollOffset + 1}-{Math.min(scrollOffset + 6, data.sota.length)} of {data.sota.length}</span>
        ) : (
          <span>{data.sota.length} spots</span>
        )}
      </div>
      <div className="text-center pb-3 text-white/40 text-base">◀ 5/5 ▶</div>
    </PageWrapper>
  )
}

// ============================================
// MAIN APP
// ============================================
function App() {
  const [data, setData] = useState<HamClockData | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentPanel, setCurrentPanel] = useState(0)
  const [scrollOffset, setScrollOffset] = useState(0)
  
  const totalPanels = 5

  const nextPanel = useCallback(() => {
    setCurrentPanel((prev) => (prev + 1) % totalPanels)
    setScrollOffset(0)
  }, [])

  const prevPanel = useCallback(() => {
    setCurrentPanel((prev) => (prev - 1 + totalPanels) % totalPanels)
    setScrollOffset(0)
  }, [])

  const scrollDown = useCallback(() => {
    if (!data) return
    const maxItems = currentPanel === 3 ? data.pota.length : currentPanel === 4 ? data.sota.length : 0
    if (scrollOffset < maxItems - 6) {
      setScrollOffset((prev) => prev + 1)
    }
  }, [currentPanel, data, scrollOffset])

  const scrollUp = useCallback(() => {
    if (scrollOffset > 0) {
      setScrollOffset((prev) => prev - 1)
    }
  }, [scrollOffset])

  useEffect(() => {
    const offData = deskthing.on('hamthing', (event: any) => {
      if (event?.payload) {
        setData(event.payload)
        setLoading(false)
      }
    })

    const offScroll = deskthing.on('scroll', (event: any) => {
      const direction = event?.payload?.direction
      if (direction === 'up') scrollUp()
      if (direction === 'down') scrollDown()
    })

    const offButton = deskthing.on('button', (event: any) => {
      const button = event?.payload?.button
      if (button === 'Digit1' || button === 'left' || button === 'back') prevPanel()
      if (button === 'Digit4' || button === 'right' || button === 'forward') nextPanel()
    })

    const offSwipe = deskthing.on('swipe', (event: any) => {
      const direction = event?.payload?.direction
      if (direction === 'left') nextPanel()
      if (direction === 'right') prevPanel()
    })

    setTimeout(() => {
      deskthing.send({ type: 'get', request: 'hamthing' })
    }, 500)

    return () => {
      offData()
      offScroll()
      offButton()
      offSwipe()
    }
  }, [nextPanel, prevPanel, scrollDown, scrollUp])

  const [touchStart, setTouchStart] = useState<number | null>(null)

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.touches[0].clientX)
  }

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStart === null) return
    const touchEnd = e.changedTouches[0].clientX
    const diff = touchStart - touchEnd
    if (Math.abs(diff) > 50) {
      if (diff > 0) nextPanel()
      else prevPanel()
    }
    setTouchStart(null)
  }

  if (loading || !data) {
    return (
      <div className="h-screen w-screen bg-gradient-to-br from-blue-950 via-sky-900 to-slate-900 flex flex-col items-center justify-center">
        <div className="text-6xl font-extralight text-white mb-6">
          📻 HamThing
        </div>
        <div className="text-2xl font-light text-white/50">Loading...</div>
      </div>
    )
  }

  return (
    <div 
      className="h-screen w-screen overflow-hidden select-none"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {currentPanel === 0 && <OverviewPanel data={data} />}
      {currentPanel === 1 && <SolarPanel data={data} />}
      {currentPanel === 2 && <PropagationPanel data={data} />}
      {currentPanel === 3 && <POTAPanel data={data} scrollOffset={scrollOffset} />}
      {currentPanel === 4 && <SOTAPanel data={data} scrollOffset={scrollOffset} />}

      {/* Panel dots */}
      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex gap-2">
        {[0, 1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
              i === currentPanel ? 'bg-white scale-125' : 'bg-white/30'
            }`}
          />
        ))}
      </div>
    </div>
  )
}

export default App
