import { DeskThing } from '@deskthing/server'
import { DESKTHING_EVENTS, SETTING_TYPES } from '@deskthing/types'

// ============================================
// CONFIGURATION
// ============================================
const HAMQSL_SOLAR_URL = 'https://www.hamqsl.com/solarxml.php'
const POTA_SPOTS_URL = 'https://api.pota.app/spot/activator'
const SOTA_SPOTS_URL = 'https://api2.sota.org.uk/api/spots/60/all'

const SOLAR_REFRESH = 300000      // 5 minutes
const POTA_REFRESH = 30000        // 30 seconds
const SOTA_REFRESH = 60000        // 1 minute

// ============================================
// TYPE DEFINITIONS
// ============================================
interface SolarData {
  updated: string
  solarflux: string
  aindex: string
  kindex: string
  kindexnt: string
  xray: string
  sunspots: string
  heliumline: string
  protonflux: string
  electronflux: string
  aurora: string
  normalization: string
  latdegree: string
  solarwind: string
  magneticfield: string
  geomagfield: string
  signalnoise: string
  fof2: string
  muffactor: string
  muf: string
  band80m_day: string
  band80m_night: string
  band40m_day: string
  band40m_night: string
  band30m_day: string
  band30m_night: string
  band20m_day: string
  band20m_night: string
  band17m_day: string
  band17m_night: string
  band15m_day: string
  band15m_night: string
  band12m_day: string
  band12m_night: string
  band10m_day: string
  band10m_night: string
}

interface POTASpot {
  spotId: number
  activator: string
  frequency: string
  mode: string
  reference: string
  parkName: string
  locationDesc: string
  spotTime: string
  spotter: string
  comments: string
  source: string
  name: string
}

interface SOTASpot {
  id: number
  userID: number
  timeStamp: string
  comments: string
  callsign: string
  associationCode: string
  summitCode: string
  activatorCallsign: string
  activatorName: string
  frequency: string
  mode: string
  summitDetails: string
  highlightColor: string
}

interface TimeData {
  utc: string
  utcDate: string
  utcDay: string
  local: string
  localDate: string
  localTimezone: string
  sunriseUTC: string
  sunsetUTC: string
  isDaytime: boolean
  grayLineInfo: string
}

interface HamThingData {
  solar: SolarData | null
  pota: POTASpot[]
  sota: SOTASpot[]
  time: TimeData
  lastUpdate: string
}

// ============================================
// STATE
// ============================================
let hamThingData: HamThingData = {
  solar: null,
  pota: [],
  sota: [],
  time: {
    utc: '',
    utcDate: '',
    utcDay: '',
    local: '',
    localDate: '',
    localTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    sunriseUTC: '06:00',
    sunsetUTC: '18:00',
    isDaytime: true,
    grayLineInfo: 'Calculating...'
  },
  lastUpdate: ''
}

// ============================================
// MODULE LEVEL VARIABLES
// ============================================
let solarInterval: ReturnType<typeof setInterval> | null = null
let potaInterval: ReturnType<typeof setInterval> | null = null
let sotaInterval: ReturnType<typeof setInterval> | null = null
let timeInterval: ReturnType<typeof setInterval> | null = null
let handlersRegistered = false  // CRITICAL: Handler guard per guide v2.2

// ============================================
// SETTINGS
// ============================================
const initializeSettings = async () => {
  const settings = {
    'callsign': {
      id: 'callsign',
      type: SETTING_TYPES.STRING,
      value: '',
      label: 'Your Callsign',
      description: 'Your amateur radio callsign (e.g., W1AW)'
    },
    'grid_square': {
      id: 'grid_square',
      type: SETTING_TYPES.STRING,
      value: '',
      label: 'Grid Square',
      description: 'Your Maidenhead grid locator (e.g., FN31pr)'
    },
    'solar_refresh': {
      id: 'solar_refresh',
      type: SETTING_TYPES.NUMBER,
      value: SOLAR_REFRESH,
      label: 'Solar Data Refresh (ms)',
      min: 60000,
      max: 600000,
      step: 60000,
      description: 'How often to fetch solar/propagation data'
    },
    'spots_refresh': {
      id: 'spots_refresh',
      type: SETTING_TYPES.NUMBER,
      value: POTA_REFRESH,
      label: 'Spots Refresh (ms)',
      min: 15000,
      max: 120000,
      step: 5000,
      description: 'How often to fetch POTA/SOTA spots'
    }
  }
  await DeskThing.initSettings(settings)
}

// ============================================
// DATA PARSING
// ============================================
const parseSolarXML = (xmlText: string): SolarData | null => {
  try {
    const getValue = (tag: string): string => {
      const match = xmlText.match(new RegExp(`<${tag}>([^<]*)</${tag}>`))
      return match ? match[1] : ''
    }

    const getBandCondition = (band: string, time: string): string => {
      const pattern = new RegExp(`<band name="${band}" time="${time}">([^<]*)</band>`)
      const match = xmlText.match(pattern)
      return match ? match[1] : 'Unknown'
    }

    // Try multiple possible tag names for MUF/foF2
    const mufValue = getValue('muf') || getValue('MUF') || getValue('calculatedmuf') || ''
    const fof2Value = getValue('fof2') || getValue('foF2') || getValue('fof') || ''
    
    // Log what we're getting for debugging
    console.log(`[HamThing] MUF raw value: "${mufValue}"`)
    console.log(`[HamThing] foF2 raw value: "${fof2Value}"`)

    return {
      updated: getValue('updated'),
      solarflux: getValue('solarflux'),
      aindex: getValue('aindex'),
      kindex: getValue('kindex'),
      kindexnt: getValue('kindexnt'),
      xray: getValue('xray'),
      sunspots: getValue('sunspots'),
      heliumline: getValue('heliumline'),
      protonflux: getValue('protonflux'),
      electronflux: getValue('electronflux'),
      aurora: getValue('aurora'),
      normalization: getValue('normalization'),
      latdegree: getValue('latdegree'),
      solarwind: getValue('solarwind'),
      magneticfield: getValue('magneticfield'),
      geomagfield: getValue('geomagfield'),
      signalnoise: getValue('signalnoise'),
      fof2: fof2Value,
      muffactor: getValue('muffactor'),
      muf: mufValue,
      band80m_day: getBandCondition('80m-40m', 'day'),
      band80m_night: getBandCondition('80m-40m', 'night'),
      band40m_day: getBandCondition('80m-40m', 'day'),
      band40m_night: getBandCondition('80m-40m', 'night'),
      band30m_day: getBandCondition('30m-20m', 'day'),
      band30m_night: getBandCondition('30m-20m', 'night'),
      band20m_day: getBandCondition('30m-20m', 'day'),
      band20m_night: getBandCondition('30m-20m', 'night'),
      band17m_day: getBandCondition('17m-15m', 'day'),
      band17m_night: getBandCondition('17m-15m', 'night'),
      band15m_day: getBandCondition('17m-15m', 'day'),
      band15m_night: getBandCondition('17m-15m', 'night'),
      band12m_day: getBandCondition('12m-10m', 'day'),
      band12m_night: getBandCondition('12m-10m', 'night'),
      band10m_day: getBandCondition('12m-10m', 'day'),
      band10m_night: getBandCondition('12m-10m', 'night')
    }
  } catch (error) {
    console.error('[HamThing] Error parsing solar XML:', error)
    return null
  }
}

// ============================================
// DATA FETCHING
// ============================================
const doFetchSolar = async () => {
  try {
    console.log('[HamThing] Fetching solar data...')
    const response = await fetch(HAMQSL_SOLAR_URL)
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    const xmlText = await response.text()
    const solarData = parseSolarXML(xmlText)
    
    if (solarData) {
      hamThingData.solar = solarData
      console.log(`[HamThing] Solar: SFI=${solarData.solarflux}, K=${solarData.kindex}`)
      sendDataToClient()
    }
  } catch (error) {
    console.error('[HamThing] Solar fetch error:', error)
  }
}

const fetchSolar = () => { doFetchSolar() }

const doFetchPOTA = async () => {
  try {
    console.log('[HamThing] Fetching POTA spots...')
    const response = await fetch(POTA_SPOTS_URL)
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    const spots: POTASpot[] = await response.json()
    hamThingData.pota = spots.slice(0, 50)
    console.log(`[HamThing] Got ${hamThingData.pota.length} POTA spots`)
    sendDataToClient()
  } catch (error) {
    console.error('[HamThing] POTA fetch error:', error)
  }
}

const fetchPOTA = () => { doFetchPOTA() }

const doFetchSOTA = async () => {
  try {
    console.log('[HamThing] Fetching SOTA spots...')
    const response = await fetch(SOTA_SPOTS_URL)
    if (!response.ok) throw new Error(`HTTP ${response.status}`)
    const spots: SOTASpot[] = await response.json()
    hamThingData.sota = spots.slice(0, 50)
    console.log(`[HamThing] Got ${hamThingData.sota.length} SOTA spots`)
    sendDataToClient()
  } catch (error) {
    console.error('[HamThing] SOTA fetch error:', error)
  }
}

const fetchSOTA = () => { doFetchSOTA() }

// ============================================
// TIME
// ============================================
const calculateGrayLine = (): string => {
  const now = new Date()
  const utcHour = now.getUTCHours()
  
  if ((utcHour >= 5 && utcHour <= 7) || (utcHour >= 17 && utcHour <= 19)) {
    return 'Gray line active — Enhanced propagation possible'
  } else if (utcHour >= 8 && utcHour <= 16) {
    return 'Daytime — Higher bands (15m-10m) may be open'
  } else {
    return 'Nighttime — Lower bands (80m-40m) favored'
  }
}

const updateTime = () => {
  const now = new Date()
  
  const utcOptions: Intl.DateTimeFormatOptions = {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
    timeZone: 'UTC'
  }
  
  const localOptions: Intl.DateTimeFormatOptions = {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }
  
  const dateOptions: Intl.DateTimeFormatOptions = {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }

  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
  
  hamThingData.time = {
    utc: now.toLocaleTimeString('en-US', utcOptions),
    utcDate: now.toLocaleDateString('en-US', { ...dateOptions, timeZone: 'UTC' }),
    utcDay: dayNames[now.getUTCDay()],
    local: now.toLocaleTimeString('en-US', localOptions),
    localDate: now.toLocaleDateString('en-US', dateOptions),
    localTimezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    sunriseUTC: '06:00',
    sunsetUTC: '18:00',
    isDaytime: now.getUTCHours() >= 6 && now.getUTCHours() < 18,
    grayLineInfo: calculateGrayLine()
  }
  
  hamThingData.lastUpdate = now.toISOString()
  sendDataToClient()
}

// ============================================
// SEND TO CLIENT
// ============================================
const sendDataToClient = () => {
  DeskThing.send({ type: 'hamthing', payload: hamThingData })
}

// ============================================
// HANDLER REGISTRATION (per guide v2.2)
// ============================================
const registerAllHandlers = () => {
  console.log('[HamThing] Registering handlers...')
  
  // Handle get requests from client
  DeskThing.on('get', (data: any) => {
    if (data?.request === 'hamthing') {
      sendDataToClient()
    }
  })
  
  // Handle button events
  DeskThing.on('button', (data: any) => {
    console.log('[HamThing] Button:', data?.payload?.button)
  })
  
  // Handle scroll events
  DeskThing.on('scroll', (data: any) => {
    console.log('[HamThing] Scroll:', data?.payload?.direction)
  })
  
  // Handle action events (for physical buttons when not focused)
  DeskThing.on(DESKTHING_EVENTS.ACTION, (data: any) => {
    console.log('[HamThing] Action:', data?.payload?.id)
  })
  
  console.log('[HamThing] Handlers registered')
}

// ============================================
// LIFECYCLE
// ============================================
const start = async () => {
  console.log('[HamThing] ═══════════════════════════════════════')
  console.log('[HamThing] Starting HamThing v2.0.0')
  console.log('[HamThing] ═══════════════════════════════════════')
  
  // REQUIRED: Initialize settings first (Rule 2)
  await initializeSettings()
  
  // Register handlers only once (Rule 5)
  if (!handlersRegistered) {
    handlersRegistered = true
    registerAllHandlers()
  }
  
  // Initial fetch
  updateTime()
  fetchSolar()
  fetchPOTA()
  fetchSOTA()
  
  // Set up intervals (Rule 6: sync wrappers)
  timeInterval = setInterval(updateTime, 1000)
  solarInterval = setInterval(fetchSolar, SOLAR_REFRESH)
  potaInterval = setInterval(fetchPOTA, POTA_REFRESH)
  sotaInterval = setInterval(fetchSOTA, SOTA_REFRESH)
  
  console.log('[HamThing] Server started successfully')
}

const stop = async () => {
  console.log('[HamThing] Stopping server...')
  
  if (timeInterval) { clearInterval(timeInterval); timeInterval = null }
  if (solarInterval) { clearInterval(solarInterval); solarInterval = null }
  if (potaInterval) { clearInterval(potaInterval); potaInterval = null }
  if (sotaInterval) { clearInterval(sotaInterval); sotaInterval = null }
  
  console.log('[HamThing] Server stopped')
}

// ============================================
// EVENT REGISTRATION (Rule 4: Only START and STOP at module level)
// ============================================
DeskThing.on(DESKTHING_EVENTS.START, start)
DeskThing.on(DESKTHING_EVENTS.STOP, stop)
