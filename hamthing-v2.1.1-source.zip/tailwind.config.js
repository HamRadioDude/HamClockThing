/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'Consolas', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite',
      },
      keyframes: {
        glow: {
          '0%, 100%': { filter: 'drop-shadow(0 0 10px currentColor)', opacity: '1' },
          '50%': { filter: 'drop-shadow(0 0 20px currentColor)', opacity: '0.8' },
        }
      },
      boxShadow: {
        'glow-amber': '0 0 30px rgba(251, 191, 36, 0.4)',
        'glow-cyan': '0 0 30px rgba(34, 211, 238, 0.4)',
        'glow-emerald': '0 0 30px rgba(52, 211, 153, 0.4)',
      }
    },
  },
  plugins: [],
}
