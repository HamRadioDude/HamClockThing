import { useEffect, useState, useCallback } from 'react'
import { DeskThing } from '@deskthing/client'

const deskthing = DeskThing

// ============================================
// TYPE DEFINITIONS
// ============================================
interface SolarData {
  updated: string
  solarflux: string
  aindex: string
  kindex: string
  kindexnt: string
  xray: string
  sunspots: string
  heliumline: string
  protonflux: string
  electronflux: string
  aurora: string
  normalization: string
  latdegree: string
  solarwind: string
  magneticfield: string
  geomagfield: string
  signalnoise: string
  fof2: string
  muffactor: string
  muf: string
  band80m_day: string
  band80m_night: string
  band40m_day: string
  band40m_night: string
  band30m_day: string
  band30m_night: string
  band20m_day: string
  band20m_night: string
  band17m_day: string
  band17m_night: string
  band15m_day: string
  band15m_night: string
  band12m_day: string
  band12m_night: string
  band10m_day: string
  band10m_night: string
}

interface POTASpot {
  spotId: number
  activator: string
  frequency: string
  mode: string
  reference: string
  parkName: string
  locationDesc: string
  spotTime: string
  spotter: string
  comments: string
  source: string
  name: string
}

interface SOTASpot {
  id: number
  timeStamp: string
  comments: string
  callsign: string
  associationCode: string
  summitCode: string
  activatorCallsign: string
  activatorName: string
  frequency: string
  mode: string
  summitDetails: string
}

interface TimeData {
  utc: string
  utcDate: string
  utcDay: string
  local: string
  localDate: string
  localTimezone: string
  sunriseUTC: string
  sunsetUTC: string
  isDaytime: boolean
  grayLineInfo: string
}

interface HamClockData {
  solar: SolarData | null
  pota: POTASpot[]
  sota: SOTASpot[]
  time: TimeData
  lastUpdate: string
}

// ============================================
// HELPER FUNCTIONS
// ============================================
const getConditionColor = (condition: string): string => {
  const c = condition?.toLowerCase() || ''
  if (c.includes('good') || c.includes('excellent')) return 'text-emerald-400'
  if (c.includes('fair') || c.includes('normal')) return 'text-amber-400'
  if (c.includes('poor') || c.includes('bad')) return 'text-rose-400'
  return 'text-slate-400'
}

const getConditionBg = (condition: string): string => {
  const c = condition?.toLowerCase() || ''
  if (c.includes('good') || c.includes('excellent')) return 'bg-emerald-500/20 border-emerald-500/40'
  if (c.includes('fair') || c.includes('normal')) return 'bg-amber-500/20 border-amber-500/40'
  if (c.includes('poor') || c.includes('bad')) return 'bg-rose-500/20 border-rose-500/40'
  return 'bg-slate-500/20 border-slate-500/40'
}

const getKIndexColor = (k: string): string => {
  const kNum = parseInt(k) || 0
  if (kNum <= 2) return 'text-emerald-400'
  if (kNum <= 4) return 'text-amber-400'
  return 'text-rose-400'
}

const getKIndexStatus = (k: string): string => {
  const kNum = parseInt(k) || 0
  if (kNum <= 1) return 'Quiet'
  if (kNum <= 2) return 'Unsettled'
  if (kNum <= 3) return 'Active'
  if (kNum <= 4) return 'Minor Storm'
  return 'Major Storm'
}

const formatTimeAgo = (isoString: string): string => {
  if (!isoString) return ''
  const now = new Date()
  const then = new Date(isoString)
  const diffMs = now.getTime() - then.getTime()
  const diffMins = Math.floor(diffMs / 60000)
  
  if (diffMins < 1) return 'now'
  if (diffMins < 60) return `${diffMins}m`
  const diffHours = Math.floor(diffMins / 60)
  if (diffHours < 24) return `${diffHours}h`
  return `${Math.floor(diffHours / 24)}d`
}

// ============================================
// GLASSMORPHISM CARD COMPONENT
// ============================================
const GlassCard = ({ children, className = '', glow = '' }: { children: React.ReactNode; className?: string; glow?: string }) => (
  <div className={`
    relative rounded-2xl border border-white/10
    bg-gradient-to-br from-white/10 to-white/5
    backdrop-blur-md shadow-2xl
    ${glow}
    ${className}
  `}>
    {children}
  </div>
)

// ============================================
// PANEL 1: OVERVIEW DASHBOARD
// ============================================
const OverviewPanel = ({ data }: { data: HamClockData }) => {
  const solar = data.solar
  
  return (
    <div className="h-full w-full flex flex-col p-3 gap-3">
      {/* Time Section */}
      <div className="flex gap-3">
        <GlassCard className="flex-1 p-4" glow="shadow-amber-500/20">
          <div className="text-amber-400/80 text-base font-semibold uppercase tracking-widest">UTC</div>
          <div className="text-amber-300 text-5xl font-bold tracking-tight drop-shadow-lg" style={{ textShadow: '0 0 30px rgba(251,191,36,0.5)' }}>
            {data.time.utc}
          </div>
          <div className="text-amber-400/60 text-lg mt-1">{data.time.utcDate}</div>
        </GlassCard>
        <GlassCard className="flex-1 p-4" glow="shadow-cyan-500/20">
          <div className="text-cyan-400/80 text-base font-semibold uppercase tracking-widest">Local</div>
          <div className="text-cyan-300 text-5xl font-bold tracking-tight drop-shadow-lg" style={{ textShadow: '0 0 30px rgba(34,211,238,0.5)' }}>
            {data.time.local}
          </div>
          <div className="text-cyan-400/60 text-lg mt-1">{data.time.localTimezone}</div>
        </GlassCard>
      </div>

      {/* Solar Indices */}
      <GlassCard className="p-4">
        <div className="grid grid-cols-6 gap-3 text-center">
          {[
            { label: 'SFI', value: solar?.solarflux, color: 'text-orange-400', glow: 'rgba(251,146,60,0.4)' },
            { label: 'SSN', value: solar?.sunspots, color: 'text-yellow-400', glow: 'rgba(250,204,21,0.4)' },
            { label: 'K', value: solar?.kindex, color: getKIndexColor(solar?.kindex || ''), glow: 'rgba(52,211,153,0.4)' },
            { label: 'A', value: solar?.aindex, color: 'text-purple-400', glow: 'rgba(192,132,252,0.4)' },
            { label: 'X-Ray', value: solar?.xray, color: 'text-pink-400', glow: 'rgba(244,114,182,0.4)' },
            { label: 'Wind', value: solar?.solarwind, color: 'text-sky-400', glow: 'rgba(56,189,248,0.4)' },
          ].map((item) => (
            <div key={item.label} className="flex flex-col items-center">
              <div className="text-slate-400 text-sm font-semibold uppercase tracking-wider">{item.label}</div>
              <div 
                className={`text-3xl font-bold ${item.color}`}
                style={{ textShadow: `0 0 20px ${item.glow}` }}
              >
                {item.value || '--'}
              </div>
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Band Conditions */}
      <GlassCard className="flex-1 p-4">
        <div className="text-slate-400 text-base font-semibold uppercase tracking-wider mb-3">Band Conditions</div>
        <div className="grid grid-cols-4 gap-3">
          {['80m', '40m', '20m', '15m'].map((band) => {
            const dayKey = `band${band.replace('m', '')}m_day` as keyof SolarData
            const condition = solar?.[dayKey] || 'Unknown'
            return (
              <div 
                key={band} 
                className={`rounded-xl border p-3 text-center ${getConditionBg(condition)}`}
              >
                <div className="text-white text-xl font-bold">{band}</div>
                <div className={`text-lg font-semibold ${getConditionColor(condition)}`}>
                  {condition.substring(0, 4)}
                </div>
              </div>
            )
          })}
        </div>
      </GlassCard>

      {/* Gray Line */}
      <GlassCard className="px-4 py-3">
        <div className="text-slate-300 text-lg flex items-center gap-2">
          <span className="text-2xl">◐</span> 
          <span>{data.time.grayLineInfo}</span>
        </div>
      </GlassCard>

      {/* Panel Indicator */}
      <div className="text-center text-slate-500 text-base">◀ 1/5 ▶</div>
    </div>
  )
}

// ============================================
// PANEL 2: SOLAR DETAILS
// ============================================
const SolarPanel = ({ data }: { data: HamClockData }) => {
  const solar = data.solar

  const DataItem = ({ label, value, color }: { label: string; value?: string; color: string }) => (
    <div className="flex justify-between items-center py-2 border-b border-white/5">
      <span className="text-slate-400 text-lg">{label}</span>
      <span className={`text-2xl font-bold ${color}`} style={{ textShadow: '0 0 15px currentColor' }}>
        {value || '--'}
      </span>
    </div>
  )

  return (
    <div className="h-full w-full flex flex-col p-3 gap-3">
      <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-500 flex items-center gap-3">
        <span className="text-4xl">☀️</span> Solar & Geomagnetic
      </div>

      <div className="flex-1 grid grid-cols-2 gap-3">
        <GlassCard className="p-4 flex flex-col" glow="shadow-amber-500/10">
          <div className="text-amber-400 text-lg font-bold uppercase tracking-wider border-b border-amber-500/30 pb-2 mb-2">
            Solar
          </div>
          <DataItem label="Solar Flux" value={solar?.solarflux} color="text-orange-400" />
          <DataItem label="Sunspots" value={solar?.sunspots} color="text-yellow-400" />
          <DataItem label="X-Ray" value={solar?.xray} color="text-pink-400" />
          <DataItem label="Proton" value={solar?.protonflux} color="text-rose-400" />
        </GlassCard>

        <GlassCard className="p-4 flex flex-col" glow="shadow-emerald-500/10">
          <div className="text-emerald-400 text-lg font-bold uppercase tracking-wider border-b border-emerald-500/30 pb-2 mb-2">
            Geomagnetic
          </div>
          <DataItem label="Kp Index" value={solar?.kindex} color={getKIndexColor(solar?.kindex || '')} />
          <DataItem label="A Index" value={solar?.aindex} color="text-purple-400" />
          <DataItem label="Solar Wind" value={solar?.solarwind ? `${solar.solarwind}` : undefined} color="text-sky-400" />
          <DataItem label="Bz Field" value={solar?.magneticfield} color="text-blue-400" />
        </GlassCard>
      </div>

      <div className="text-center text-slate-500 text-base">Updated: {solar?.updated || 'Never'}</div>
      <div className="text-center text-slate-500 text-base">◀ 2/5 ▶</div>
    </div>
  )
}

// ============================================
// PANEL 3: PROPAGATION
// ============================================
const PropagationPanel = ({ data }: { data: HamClockData }) => {
  const solar = data.solar
  
  const bands = [
    { name: '80m', dayKey: 'band80m_day', nightKey: 'band80m_night' },
    { name: '40m', dayKey: 'band40m_day', nightKey: 'band40m_night' },
    { name: '30m', dayKey: 'band30m_day', nightKey: 'band30m_night' },
    { name: '20m', dayKey: 'band20m_day', nightKey: 'band20m_night' },
    { name: '17m', dayKey: 'band17m_day', nightKey: 'band17m_night' },
    { name: '15m', dayKey: 'band15m_day', nightKey: 'band15m_night' },
    { name: '12m', dayKey: 'band12m_day', nightKey: 'band12m_night' },
    { name: '10m', dayKey: 'band10m_day', nightKey: 'band10m_night' },
  ]

  return (
    <div className="h-full w-full flex flex-col p-3 gap-3">
      <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500 flex items-center gap-3">
        <span className="text-4xl">📊</span> HF Propagation
      </div>

      <GlassCard className="flex-1 overflow-hidden">
        <div className="grid grid-cols-3 bg-white/5 px-4 py-3 border-b border-white/10">
          <div className="text-slate-400 text-lg font-bold">Band</div>
          <div className="text-amber-400 text-lg font-bold text-center">Day</div>
          <div className="text-blue-400 text-lg font-bold text-center">Night</div>
        </div>
        
        <div className="divide-y divide-white/5">
          {bands.map((band) => {
            const dayCondition = solar?.[band.dayKey as keyof SolarData] || '—'
            const nightCondition = solar?.[band.nightKey as keyof SolarData] || '—'
            
            return (
              <div key={band.name} className="grid grid-cols-3 px-4 py-2 hover:bg-white/5 transition-colors">
                <div className="text-white text-xl font-bold">{band.name}</div>
                <div className={`text-xl font-semibold text-center ${getConditionColor(dayCondition)}`}>
                  {dayCondition}
                </div>
                <div className={`text-xl font-semibold text-center ${getConditionColor(nightCondition)}`}>
                  {nightCondition}
                </div>
              </div>
            )
          })}
        </div>
      </GlassCard>

      <GlassCard className="px-4 py-3 flex justify-around">
        <span className="text-lg">
          <span className="text-slate-400">MUF:</span>{' '}
          <span className="text-cyan-400 font-bold text-xl" style={{ textShadow: '0 0 15px rgba(34,211,238,0.5)' }}>
            {solar?.muf || '--'} MHz
          </span>
        </span>
        <span className="text-lg">
          <span className="text-slate-400">foF2:</span>{' '}
          <span className="text-emerald-400 font-bold text-xl" style={{ textShadow: '0 0 15px rgba(52,211,153,0.5)' }}>
            {solar?.fof2 || '--'} MHz
          </span>
        </span>
      </GlassCard>

      <div className="text-center text-slate-500 text-base">◀ 3/5 ▶</div>
    </div>
  )
}

// ============================================
// PANEL 4: POTA SPOTS
// ============================================
const POTAPanel = ({ data, scrollOffset }: { data: HamClockData; scrollOffset: number }) => {
  const visibleSpots = data.pota.slice(scrollOffset, scrollOffset + 4)

  return (
    <div className="h-full w-full flex flex-col p-3 gap-3">
      <div className="flex justify-between items-center">
        <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-green-500 flex items-center gap-3">
          <span className="text-4xl">🏕️</span> POTA Spots
        </div>
        <div className="text-emerald-400 text-xl font-bold px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-500/40">
          {data.pota.length} active
        </div>
      </div>

      <GlassCard className="flex-1 overflow-hidden">
        {visibleSpots.length > 0 ? (
          <div className="divide-y divide-white/5">
            {visibleSpots.map((spot, i) => (
              <div key={spot.spotId || i} className="px-4 py-3 hover:bg-white/5 transition-colors">
                <div className="flex justify-between items-start">
                  <div className="flex items-baseline gap-2">
                    <span className="text-amber-300 font-bold text-2xl" style={{ textShadow: '0 0 15px rgba(252,211,77,0.5)' }}>
                      {spot.activator}
                    </span>
                    <span className="text-slate-400 text-lg">{spot.mode}</span>
                  </div>
                  <span className="text-cyan-400 font-bold text-xl">{spot.frequency}</span>
                </div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-emerald-400 text-lg font-semibold">{spot.reference}</span>
                  <span className="text-slate-500 text-lg">{formatTimeAgo(spot.spotTime)}</span>
                </div>
                <div className="text-slate-400 text-base truncate mt-1">{spot.parkName}</div>
              </div>
            ))}
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-slate-500 text-xl">
            No POTA spots available
          </div>
        )}
      </GlassCard>

      {data.pota.length > 4 && (
        <div className="text-slate-500 text-base text-center">
          {scrollOffset + 1}-{Math.min(scrollOffset + 4, data.pota.length)} of {data.pota.length} • dial to scroll
        </div>
      )}
      <div className="text-center text-slate-500 text-base">◀ 4/5 ▶</div>
    </div>
  )
}

// ============================================
// PANEL 5: SOTA SPOTS
// ============================================
const SOTAPanel = ({ data, scrollOffset }: { data: HamClockData; scrollOffset: number }) => {
  const visibleSpots = data.sota.slice(scrollOffset, scrollOffset + 4)

  return (
    <div className="h-full w-full flex flex-col p-3 gap-3">
      <div className="flex justify-between items-center">
        <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-500 flex items-center gap-3">
          <span className="text-4xl">⛰️</span> SOTA Spots
        </div>
        <div className="text-orange-400 text-xl font-bold px-3 py-1 rounded-full bg-orange-500/20 border border-orange-500/40">
          {data.sota.length} active
        </div>
      </div>

      <GlassCard className="flex-1 overflow-hidden">
        {visibleSpots.length > 0 ? (
          <div className="divide-y divide-white/5">
            {visibleSpots.map((spot, i) => (
              <div key={spot.id || i} className="px-4 py-3 hover:bg-white/5 transition-colors">
                <div className="flex justify-between items-start">
                  <div className="flex items-baseline gap-2">
                    <span className="text-amber-300 font-bold text-2xl" style={{ textShadow: '0 0 15px rgba(252,211,77,0.5)' }}>
                      {spot.activatorCallsign}
                    </span>
                    <span className="text-slate-400 text-lg">{spot.mode}</span>
                  </div>
                  <span className="text-cyan-400 font-bold text-xl">{spot.frequency}</span>
                </div>
                <div className="flex justify-between items-center mt-1">
                  <span className="text-orange-400 text-lg font-semibold">
                    {spot.associationCode}/{spot.summitCode}
                  </span>
                  <span className="text-slate-500 text-lg">{formatTimeAgo(spot.timeStamp)}</span>
                </div>
                {spot.comments && (
                  <div className="text-slate-400 text-base truncate mt-1">{spot.comments}</div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="h-full flex items-center justify-center text-slate-500 text-xl">
            No SOTA spots available
          </div>
        )}
      </GlassCard>

      {data.sota.length > 4 && (
        <div className="text-slate-500 text-base text-center">
          {scrollOffset + 1}-{Math.min(scrollOffset + 4, data.sota.length)} of {data.sota.length} • dial to scroll
        </div>
      )}
      <div className="text-center text-slate-500 text-base">◀ 5/5 ▶</div>
    </div>
  )
}

// ============================================
// MAIN APP
// ============================================
function App() {
  const [data, setData] = useState<HamClockData | null>(null)
  const [loading, setLoading] = useState(true)
  const [currentPanel, setCurrentPanel] = useState(0)
  const [scrollOffset, setScrollOffset] = useState(0)
  
  const totalPanels = 5

  const nextPanel = useCallback(() => {
    setCurrentPanel((prev) => (prev + 1) % totalPanels)
    setScrollOffset(0)
  }, [])

  const prevPanel = useCallback(() => {
    setCurrentPanel((prev) => (prev - 1 + totalPanels) % totalPanels)
    setScrollOffset(0)
  }, [])

  const scrollDown = useCallback(() => {
    if (!data) return
    const maxItems = currentPanel === 3 ? data.pota.length : currentPanel === 4 ? data.sota.length : 0
    if (scrollOffset < maxItems - 4) {
      setScrollOffset((prev) => prev + 1)
    }
  }, [currentPanel, data, scrollOffset])

  const scrollUp = useCallback(() => {
    if (scrollOffset > 0) {
      setScrollOffset((prev) => prev - 1)
    }
  }, [scrollOffset])

  useEffect(() => {
    const offData = deskthing.on('hamthing', (event: any) => {
      if (event?.payload) {
        setData(event.payload)
        setLoading(false)
      }
    })

    const offScroll = deskthing.on('scroll', (event: any) => {
      const direction = event?.payload?.direction
      if (direction === 'up') scrollUp()
      if (direction === 'down') scrollDown()
    })

    const offButton = deskthing.on('button', (event: any) => {
      const button = event?.payload?.button
      if (button === 'Digit1' || button === 'left' || button === 'back') prevPanel()
      if (button === 'Digit4' || button === 'right' || button === 'forward') nextPanel()
    })

    const offSwipe = deskthing.on('swipe', (event: any) => {
      const direction = event?.payload?.direction
      if (direction === 'left') nextPanel()
      if (direction === 'right') prevPanel()
    })

    setTimeout(() => {
      deskthing.send({ type: 'get', request: 'hamthing' })
    }, 500)

    return () => {
      offData()
      offScroll()
      offButton()
      offSwipe()
    }
  }, [nextPanel, prevPanel, scrollDown, scrollUp])

  const [touchStart, setTouchStart] = useState<number | null>(null)

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.touches[0].clientX)
  }

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStart === null) return
    const touchEnd = e.changedTouches[0].clientX
    const diff = touchStart - touchEnd
    if (Math.abs(diff) > 50) {
      if (diff > 0) nextPanel()
      else prevPanel()
    }
    setTouchStart(null)
  }

  if (loading || !data) {
    return (
      <div className="h-screen w-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex flex-col items-center justify-center">
        <div 
          className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-500 to-amber-400 mb-6"
          style={{ textShadow: '0 0 40px rgba(251,191,36,0.3)' }}
        >
          📻 HamThing
        </div>
        <div className="text-slate-400 text-2xl animate-pulse">Loading ham radio data...</div>
        <div className="mt-8 flex gap-3">
          {[0, 1, 2].map((i) => (
            <div 
              key={i}
              className="w-4 h-4 bg-gradient-to-r from-amber-400 to-orange-500 rounded-full animate-bounce"
              style={{ animationDelay: `${i * 150}ms` }}
            />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div 
      className="h-screen w-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white overflow-hidden select-none"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Ambient glow effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      
      {/* Panel Content */}
      <div className="relative h-full w-full">
        {currentPanel === 0 && <OverviewPanel data={data} />}
        {currentPanel === 1 && <SolarPanel data={data} />}
        {currentPanel === 2 && <PropagationPanel data={data} />}
        {currentPanel === 3 && <POTAPanel data={data} scrollOffset={scrollOffset} />}
        {currentPanel === 4 && <SOTAPanel data={data} scrollOffset={scrollOffset} />}
      </div>

      {/* Panel Dots */}
      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex gap-2">
        {[0, 1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              i === currentPanel 
                ? 'bg-gradient-to-r from-amber-400 to-orange-500 scale-125 shadow-lg shadow-amber-500/50' 
                : 'bg-slate-600'
            }`}
          />
        ))}
      </div>
    </div>
  )
}

export default App
